import { Router } from "express";
import {methods as detalleController} from "../controllers/detalle.controller.js"

const router = Router();

router.get("/", detalleController.getDetalles);
router.get("/filtrados", detalleController.getDetallesReducidos);
router.get("/anticipos", detalleController.getAnticipo);
router.get("/:id", detalleController.getDetalle);
router.post("/", detalleController.addDetalle);
router.delete("/:id", detalleController.removeDetalle);
router.put("/update", detalleController.updateDetalle);

export default router;