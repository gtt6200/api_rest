import express from "express";
import morgan from "morgan";
import cors from "cors";
//routes importadas
import detalleRoutes from "./routes/detalle.routes.js";


const app=express();

//settings
app.set("port", 4201);

//middelwares
app.use(morgan("dev"));
app.use(express.json());
app.use(cors({
    origin:"http://localhost:4200",
    methods:["GET", "PUT"]
}))

//routes
app.use("/api/detalle", detalleRoutes);

export default app;